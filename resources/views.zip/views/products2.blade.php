<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Planet Shopify | Online Shopping Site for Women</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a09adcde7e.js" crossorigin="anonymous"></script>
    <link href='https://fonts.googleapis.com/css?family=Delius Swash Caps' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Andika' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<!--header -->


<!--Navigation bar start-->
<nav class="navbar fixed-top navbar-expand-sm navbar-dark" style="background-color:rgba(0,0,0,0.5)">


    <a href="index.php" class="navbar-brand">
             <!-- <img src="img/Bikshop.png" alt="company logo" /> -->
             <div class="timeline-image"><img class="rounded-circle img-fluid" src="images/Bikshop_logo.png" alt="..." style="width: 50px;
        height: 50px;"></div>
            </a>
    
    
                <div class="container">
                        <a href="/index" class="navbar-brand" style="font-family: 'Delius Swash Caps'">Bik Shopping</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynavbar">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                    <div class="collapse navbar-collapse" id="mynavbar">
                        <ul class="nav navbar-nav">
                           <li class="nav-item dropdown">
                               <a href="" class="nav-link dropdown-toggle" id="navbar-drop" data-toggle="dropdown">
                                   Products
                                </a>
                                   <div class="dropdown-menu">
                                       <!-- <a href="products.php#watch" class="dropdown-item">Watches</a> -->
                                       <a href="/products" class="dropdown-item">Clothing</a>
                                       <a href="/products2" class="dropdown-item">Trousers</a>
                                       <!-- <a href="products.php#headphones" class="dropdown-item">Headphones/Speakers</a> -->
                                   </div>
                               
                           </li>
                           <li class="nav-item"><a href="index" class="nav-link" >Offers</a></li>
                           <li class="nav-item"><a href="about" class="nav-link" >Wishlist</a></li>
                           <?php
                           if (isset($_SESSION['email'])) {
                            ?>
                           <li class="nav-item"><a href="cart.php" class="nav-link">Cart</a></li>
                           <?php
                              } 
                        ?>
                        </ul>
                        
                        <?php
                    if (isset($_SESSION['email'])) {
                        ?>
                        <ul class="nav navbar-nav ml-auto">
                           <li class="nav-item"><a href="logout_script.php" class="nav-link"><i class="fa fa-sign-out"></i>Logout</a></li>
                           <li class="nav-item"><a  class="nav-link " data-placement="bottom" data-toggle="popover" data-trigger="hover" data-content="<?php echo $_SESSION['email'] ?>"><i class="fa fa-user-circle "></i></a></li>
                        </ul>
                        <?php
                    } else {
                        ?>
                        <ul class="nav navbar-nav ml-auto">
                           <li class="nav-item "><a href="#signup" class="nav-link"data-toggle="modal" ><i class="fa fa-user"></i> Sign Up</a></li>
                           <li class="nav-item "><a href="#login" class="nav-link" data-toggle="modal"><i class="fa fa-sign-in"></i> Login</a></li>
                        </ul>
                        <?php 
                    }
                        ?>
                        </div>
                    </div>
                </div>
            </nav>
        <!--navigation bar end-->
        <!--Login trigger Modal-->
        <div class="modal fade" id="login" >
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content"style="background-color:rgba(255,255,255,0.95)">
    
                <div class="modal-header">
                  <h5 class="modal-title">Login</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
    
                <div class="modal-body">
                  <form action="login_script.php" method="post">
                     <div class="form-group">
                         <label for="email">Email address:</label>
                         <input type="email" class="form-control"  name="lemail" placeholder="Enter email" required>
                    </div>
                    <div class="form-group">
                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="pwd"  name="lpassword" placeholder="Password" required>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input">
                        <label for="checkbox" class="form-check-label">Check me out</label>
                    </div>
                    <button type="submit" class="btn btn-secondary btn-block" name="Submit">Login</button>
                  </form>
                  <a href="http://">forgot password ?</a>
                </div>
                <div class="modal-footer">
                  <p class="mr-auto">New User? <a href="#signup" data-toggle="modal" data-dismiss="modal" >signup</a></p>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div>
        <!--Login trigger Model ends-->
        <!--Signup model start-->
        <div class="modal fade" id="signup">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content" style="background-color:rgba(255,255,255,0.95)">
    
                <div class="modal-header">
                  <h5 class="modal-title">Sign Up</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
    
                <div class="modal-body">
                  <form action="signup_script.php" method="post">
                    <div class="form-group">
                         <label for="email">Email address:</label>
                         <input type="email" class="form-control"  name="eMail" placeholder="Enter email" required>
                         <?php if(isset($_GET['error'])){ echo "<span class='text-danger'>".$_GET['error']."</span>" ;}  ?>
                    </div>
                    <div class="form-group">
                        <label for="pwd">Password:</label>
                        <input type="password" class="form-control" id="pwd" name="password" placeholder="Password" required>
                    </div>
    
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="validation1">First Name</label>
                            <input type="text" class="form-control" id="validation1" name="firstName" placeholder="First Name" required>
                        </div>
                        <div class="form-group col-md -6">
                            <label for="validation2">Last Name</label>
                            <input type="text" class="form-control" id="validation2" name="lastName" placeholder="Last Name">
                        </div>
                    </div>
                    
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" required>
                        <label for="checkbox" class="form-check-label">Agree terms and Condition</label>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block" name="Submit">Sign Up</button>
                  </form>
                </div>
                <div class="modal-footer">
                  <p class="mr-auto">Already Registered?<a href="#login"  data-toggle="modal" data-dismiss="modal">Login</a></p>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal" >Close</button>
                </div>
              </div>
            </div>
          </div>
          <!--Signup trigger model ends-->

          <?php
//This code checks if the product is added to cart. 
function check_if_added_to_cart($item_id) {
    
    $user_id = $_SESSION['user_id']; 
    require("common.php");
   
    $query = "SELECT * FROM users_products WHERE item_id='$item_id' AND user_id ='$user_id' and status='Added to cart'";
    $result = mysqli_query($con, $query);
    

    if (mysqli_num_rows($result) >= 1) {
        return 1;
    } else {
        return 0;
    }
}

?>
 <?php

?>
<!--header ends -->
<div class="container" style="margin-top:65px">
         <!--jumbutron start-->
        <div class="jumbotron text-center">
            <h1>Welcome to Bik Shopping!</h1>
            <p>We have wide range of products for you.No need to hunt around,we have all in one place</p>
        </div>
        <!--jumbutron ends-->
        <!--breadcrumb start-->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Products</li>
            </ol>
        </nav>
        <!--breadcrumb end-->
    <hr/>
    <!--menu list-->
    <div class="row text-center justify-content-center" id="watch" style="padding-bottom:40px">
        <div class="col-md-3 col-6 py-2">
            <div class="card">
                <img src="images/CulloteJeans.jpg" alt="" class="img-fluid pb-1" >
                <div class="figure-caption">
                    <h6>Celana Cullote Jeans</h6>
                    <h6>Price :Rp 110000</h6>
                    <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                    <?php
                    } else {
                    if (check_if_added_to_cart(8)) {
                     echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                    } else {
                        ?>
                        <p><a href="-" name="add" value="add" class="btn btn-warning  text-white">Wishlist</a></p>
                        <p><a href="cart-add.php?id=1" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a><p>
                        <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6 py-2">
            <div class="card">
                <img src="images/Jogger.jpg" alt="" class="img-fluid pb-1">
                <div class="figure-caption">
                    <h6>Celana Jogger Jeans</h6>
                    <h6>Price :Rp 160000</h6>
                    <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                    <?php
                    } else {
                        if (check_if_added_to_cart(9)) {
                        echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                         } else {
                        ?>
                        <p><a href="-" name="add" value="add" class="btn btn-warning  text-white">Wishlist</a></p>
                        <p><a href="cart-add.php?id=2" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a></p>
                        <?php
                         }
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6 py-2">
            <div class="card">
                <img src="images/CelanaP&B.jpg" alt="" class="img-fluid pb-1">
                <div class="figure-caption">
                    <h6>Celana Pull & Bear</h6>
                    <h6>Price :Rp 180000</h6>
                    <?php if (!isset($_SESSION['email'])) {?>
                    <p><a href="index.php#login" role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                    <?php
                    } else {
                        if (check_if_added_to_cart(10)) {
                        echo '<p><a href="#" class="btn btn-warning  text-white" disabled>Added to cart</a></p>';
                        } else {
                        ?>
                        <p><a href="-" name="add" value="add" class="btn btn-warning  text-white">Wishlist</a></p>
                        <p><a href="cart-add.php?id=3" name="add" value="add" class="btn btn-warning  text-white">Add to cart</a></p>
                        <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
      <!--menu list ends-->
      <!-- footer-->
      <footer class="footer">
        <div class="container text-center"><span class="text-muted"><b>Copyright&copy;Planet Shopify | All Rights Reserved | Contact Us: +91 90000 00000</b></span></div>
    </footer>
      <!--footer ends-->

   <!-- footer section -->
   <footer class="footer py-5">
      <div class="container">
        <div class="row">
          <div class="col-10 mx-auto text-center">
            <!-- footer icons -->
            <div class="footer-contact d-flex justify-content-around mt-5">
              <!-- single contact -->
              <div class="text-capitalize">
                <p>
                <span class="contact-icon mr-2">
                  <i class="fa-brands fa-instagram"></i>
                </span>
                Instagram : <a href="https://www.instagram.com/biakshopping/" target="_blank" rel="noopener noreferrer" style="color:#ffc107;"> @biakshopping </a></p>
              </div>
              <!-- end of single contact -->
              <!-- single contact -->
              <div class="text-capitalize">
              <p>
                <span class="contact-icon mr-2">
                  <i class="fa-brands fa-whatsapp"></i>
                </span>
                Whatsapp : <a href="https://api.whatsapp.com/send?phone=82197677746&text=Halo%20saya%20ingin%20bertanya%20mengenai%20produk%20anda%20di%20Biak%20Shopping" target="_blank" rel="noopener noreferrer" style="color:#ffc107;"> +62-821-9767-7746 </a></p>
              </div>
              <!-- end of single contact -->
              <!-- single contact -->
              <div class="text-capitalize">
                <p>
                <span class="contact-icon mr-2">
                  <i class="fas fa-envelope"></i>
                </span>
                Email : <a href="https://mail.google.com/mail/u/0/#compose" target="_blank" rel="noopener noreferrer" style="color:#ffc107;"> biakshopping@gmail.com </a></p>
              </div>
              <!-- end of single contact -->
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- end of footer section -->

</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
  $('[data-toggle="popover"]').popover();
});
</script>
<?php if (isset($_GET['error'])) {$z = $_GET['error'];
    echo "<script type='text/javascript'>
$(document).ready(function(){
$('#signup').modal('show');
});
</script>";
    echo "<script type='text/javascript'>alert('" . $z . "')</script>";}?>
<?php if (isset($_GET['errorl'])) {$z = $_GET['errorl'];
    echo "<script type='text/javascript'>
$(document).ready(function(){
$('#login').modal('show');
});
</script>";
    echo "<script type='text/javascript'>alert('" . $z . "')</script>";}?>
</html>