<nav>
  <ul class="pagination pagination-sm">
    <li class="page-item"><a class="page-link" href="">Prev</a><li>
    <li class="page-item"><a class="page-link" href="">1</a><li>
    <li class="page-item"><a class="page-link" href="">2</a><li>
    <li class="page-item"><a class="page-link" href="">Next</a><li>
</ul>
</nav>
