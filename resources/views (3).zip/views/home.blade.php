<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body style="margin-bottom:200px">
    {{ $nama }} <br>
    {{ $kota }} <br>
    {{ $sekolah }}
</body>
