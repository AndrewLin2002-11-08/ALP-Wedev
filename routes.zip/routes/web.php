<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/header', function () {
    return view('header');
});

Route::get('/about', function () {
    return view('about');
});

Route::get('/index', function () {
    return view('index');
});

Route::get('/products', function () {
    return view('products');
});

Route::get('/check-if-added', function () {
    return view('check-if-added');
});

Route::get('/common', function () {
    return view('common');
});

Route::get('/footer', function () {
    return view('footer');
});

Route::get('/artisan', function () {
    return view('artisan');
});

Route::get('/cart-add', function () {
    return view('card-add');
});

Route::get('/cart-remove', function () {
    return view('cart-remove');
});

Route::get('/cart', function () {
    return view('cart');
});


Route::GET('/cek_atc/{id}', function (string $id) {
    return view('cart-add', ['id' => $id]);
});

Route::get('/logout', function () {
    return view('logout');
});

Route::get('/products', function () {
    return view('products');
});

Route::get('/products2', function () {
    return view('products2');
});


Route::get('/success', function () {
    return view('success');
});

Route::get('/login', [LoginController::class, 'index']);
Route::post('/login', [LoginController::class, 'authenticate']);
Route::post('/logout', [LoginController::class, 'logout']);

Route::get('/register', [RegisterController::class, 'index']);
Route::post('/register', [RegisterController::class, 'store']);

